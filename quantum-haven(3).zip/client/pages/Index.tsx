import { Layout } from "@/components/Layout";
import { HeroSection } from "@/components/HeroSection";
import { ServicesSection } from "@/components/ServicesSection";
import { FeaturesSection } from "@/components/FeaturesSection";
import { InstapaySection } from "@/components/InstapaySection";
import { TestimonialsSection } from "@/components/TestimonialsSection";
import { FAQSection } from "@/components/FAQSection";
import { BranchesSection } from "@/components/BranchesSection";
import { CTASection } from "@/components/CTASection";

export default function Index() {
  return (
    <Layout>
      <HeroSection />
      <ServicesSection />
      <FeaturesSection />
      <InstapaySection />
      <TestimonialsSection />
      <FAQSection />
      <BranchesSection />
      <CTASection />
    </Layout>
  );
}
