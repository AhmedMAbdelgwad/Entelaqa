import { Layout } from "@/components/Layout";
import { useTranslation } from "react-i18next";
import {
  MessageSquare,
  Building2,
  Calculator,
  Plane,
  CheckCircle,
  FileText,
  Home,
  Package,
  Lightbulb,
  Scale,
  Car,
} from "lucide-react";

export default function Services() {
  const { t } = useTranslation();

  const serviceDetails = [
    {
      id: 1,
      title: t("services.legalConsultations"),
      icon: MessageSquare,
      description: t("services.legalConsultationsDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.legalConsultations",
    },
    {
      id: 2,
      title: t("services.companyFormation"),
      icon: Building2,
      description: t("services.companyFormationDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.companyFormation",
    },
    {
      id: 3,
      title: t("services.accounting"),
      icon: Calculator,
      description: t("services.accountingDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.accounting",
    },
    {
      id: 4,
      title: t("services.procedural"),
      icon: FileText,
      description: t("services.proceduralDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.procedural",
    },
    {
      id: 5,
      title: t("services.realEstate"),
      icon: Home,
      description: t("services.realEstateDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.realEstate",
    },
    {
      id: 6,
      title: t("services.customs"),
      icon: Package,
      description: t("services.customsDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.customs",
    },
    {
      id: 7,
      title: t("services.intellectualProperty"),
      icon: Lightbulb,
      description: t("services.intellectualPropertyDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.intellectualProperty",
    },
    {
      id: 8,
      title: t("services.abroadServices"),
      icon: Plane,
      description: t("services.abroadServicesDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.abroadServices",
    },
    {
      id: 9,
      title: t("services.disputes"),
      icon: Scale,
      description: t("services.disputesDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.disputes",
    },
    {
      id: 10,
      title: t("services.vehicleLicenses"),
      icon: Car,
      description: t("services.vehicleLicensesDesc"),
      detailKeys: ["detail1", "detail2", "detail3", "detail4"],
      serviceKey: "services.vehicleLicenses",
    },
  ];

  return (
    <Layout>
      {/* Hero Section */}
      <section className="gradient-hero text-white py-16 md:py-24">
        <div className="section-container">
          <div className="text-center space-y-4">
            <h1>{t("services.title")}</h1>
            <p className="text-xl text-gray-100 max-w-2xl mx-auto">
              {t("services.subtitle")}
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="section">
        <div className="section-container">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {serviceDetails.map((service) => {
              const Icon = service.icon;
              return (
                <div key={service.id} className="card-base p-8 hover:shadow-xl transition-all">
                  <Icon className="w-12 h-12 text-primary mb-4" />
                  <h2 className="text-2xl font-bold mb-3">{service.title}</h2>
                  <p className="text-gray-600 dark:text-gray-400 mb-6">
                    {service.description}
                  </p>
                  <h3 className="font-semibold text-primary mb-3">{t("services.mainServices")}:</h3>
                  <ul className="space-y-2">
                    {service.detailKeys.map((detailKey, idx) => (
                      <li key={idx} className="flex items-start gap-2 text-gray-700 dark:text-gray-300">
                        <span className="text-accent font-bold mt-1">✓</span>
                        <span>{t(`${service.serviceKey}.${detailKey}`)}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section bg-gray-50 dark:bg-gray-900">
        <div className="section-container">
          <div className="gradient-hero rounded-2xl p-8 md:p-16 text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {t("cta.heading")}
            </h2>
            <p className="text-lg text-gray-100 mb-8 max-w-2xl mx-auto">
              {t("cta.subheading")}
            </p>
            <a href="/contact" className="btn-primary inline-block">
              {t("nav.bookConsultation")}
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
}
