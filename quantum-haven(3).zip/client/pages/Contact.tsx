import { Layout } from "@/components/Layout";
import { Mail, MapPin, Phone, Clock } from "lucide-react";
import { useState } from "react";
import { useTranslation } from "react-i18next";

export default function Contact() {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    phone: "",
    subject: "",
    message: "",
  });

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log("Form submitted:", formData);
    setFormData({ name: "", email: "", phone: "", subject: "", message: "" });
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="gradient-hero text-white py-16 md:py-24">
        <div className="section-container">
          <div className="text-center space-y-4">
            <h1>{t("contact.title")}</h1>
            <p className="text-xl text-gray-100 max-w-2xl mx-auto">
              {t("contact.subtitle")}
            </p>
          </div>
        </div>
      </section>

      {/* Contact Section */}
      <section className="section">
        <div className="section-container">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
            {/* Contact Info Cards */}
            {[
              {
                icon: Phone,
                title: t("footer.phone"),
                value: "+20 1061963341",
                link: "tel:+201061963341",
              },
              {
                icon: Mail,
                title: t("contact.email"),
                value: "entelaqa.law@gmail.com",
                link: "entelaqa.law@gmail.com",
              },
              {
                icon: MapPin,
                title: t("footer.address"),
                value: "37 شارع ربيع الجيزي - الجيزة - مصر",
                link: "#",
              },
            ].map((contact, idx) => {
              const Icon = contact.icon;
              return (
                <a
                  key={idx}
                  href={contact.link}
                  className="card-base p-8 text-center hover:shadow-xl transition-all"
                >
                  <Icon className="w-10 h-10 text-primary mx-auto mb-4" />
                  <h3 className="font-bold text-lg mb-2">{contact.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400">{contact.value}</p>
                </a>
              );
            })}
          </div>

          {/* Contact Form and Info Grid */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            {/* Contact Form */}
            <div className="card-base p-8">
              <h2 className="text-2xl font-bold mb-6">{t("contact.title")}</h2>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    {t("contact.name")}
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    placeholder={t("contact.name")}
                    className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    {t("contact.email")}
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    placeholder={t("contact.email")}
                    className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    {t("contact.phone")}
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    placeholder={t("contact.phone")}
                    className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-900"
                    required
                  />
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    {t("contact.chooseService")}
                  </label>
                  <select
                    name="subject"
                    value={formData.subject}
                    onChange={handleChange}
                    className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-900"
                    required
                  >
                    <option value="">{t("contact.chooseServicePlaceholder")}</option>
                    <option value="استشارة_قانونية">{t("services.legalConsultations")}</option>
                    <option value="تأسيس_شركة">{t("services.companyFormation")}</option>
                    <option value="حسابات_ضرائب">{t("services.accounting")}</option>
                    <option value="خدمات_اجرائية">{t("services.procedural")}</option>
                    <option value="خدمات_عقارية">{t("services.realEstate")}</option>
                    <option value="جمارك">{t("services.customs")}</option>
                    <option value="تراخيص_سيارات">{t("services.vehicleLicenses")}</option>
                    <option value="ملكية_فكرية">{t("services.intellectualProperty")}</option>
                    <option value="اخرى">{t("services.optionOther")}</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-semibold mb-2 text-foreground">
                    {t("contact.message")}
                  </label>
                  <textarea
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    placeholder={t("contact.message")}
                    rows={5}
                    className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-900"
                    required
                  />
                </div>
                <button type="submit" className="btn-primary w-full">
                  {t("contact.sendButton")}
                </button>
              </form>
            </div>

            {/* Contact Info */}
            <div className="space-y-6">
              <div className="card-base p-8">
                <h2 className="text-2xl font-bold mb-6">معلومات التواصل</h2>
                <div className="space-y-4">
                  <div className="flex gap-4">
                    <Clock className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">مواعيد العمل</h3>
                      <p className="text-gray-600 dark:text-gray-400">
                        الأحد - الخميس: 9:00 - 17:00
                      </p>
                      <p className="text-gray-600 dark:text-gray-400">
                        الجمعة والسبت: مغلق
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 pt-4 border-t border-border">
                    <Phone className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">{t("footer.phone")}</h3>
                      <p className="text-gray-600 dark:text-gray-400">
                        <a href="tel:+201061963341" className="hover:text-primary">
                          +20 1061963341
                        </a>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 pt-4 border-t border-border">
                    <Mail className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">{t("contact.email")}</h3>
                      <p className="text-gray-600 dark:text-gray-400">
                        <a href="mailto:entelaqa.law@gmail.com" className="hover:text-primary">
                          entelaqa.law@gmail.com
                        </a>
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4 pt-4 border-t border-border">
                    <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h3 className="font-semibold mb-1">{t("footer.address")}</h3>
                      <p className="text-gray-600 dark:text-gray-400">
                        37 شارع ربيع الجيزي - الجيزة - مصر
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              <div className="card-base p-8 bg-primary text-primary-foreground">
                <h3 className="text-lg font-bold mb-4">استشارة مجانية</h3>
                <p className="mb-4">
                  اتصل بنا لحجز استشارتك الأولى مجاناً وتعرف على كيفية مساعدتنا لك
                </p>
                <a href="tel:+201061963341" className="inline-block btn-primary bg-white text-primary hover:bg-gray-100">
                  {t("nav.bookConsultation")}
                </a>
              </div>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
}
