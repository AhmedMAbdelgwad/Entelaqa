import { Layout } from "@/components/Layout";
import { Award, Users, Target, Heart } from "lucide-react";
import { useTranslation } from "react-i18next";
import { TeamMemberCard } from "@/components/TeamMemberCard";

export default function About() {
  const { t } = useTranslation();
  return (
    <Layout>
      {/* Hero Section */}
      <section className="gradient-hero text-white py-16 md:py-24">
        <div className="section-container">
          <div className="text-center space-y-4">
            <h1>{t("about.pageTitle")}</h1>
            <p className="text-xl text-gray-100 max-w-2xl mx-auto">
              {t("about.pageSubtitle")}
            </p>
          </div>
        </div>
      </section>

      {/* Company Story */}
      <section className="section">
        <div className="section-container">
          <div className="max-w-3xl mx-auto">
            <div className="card-base p-8 md:p-12">
              <h2 className="text-3xl font-bold mb-6">{t("about.story")}</h2>
              <p className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed mb-4">
                {t("about.storyContent1")}
              </p>
              <p className="text-lg text-gray-600 dark:text-gray-400 leading-relaxed">
                {t("about.storyContent2")}
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section className="section bg-gray-50 dark:bg-gray-900">
        <div className="section-container">
          <h2 className="section-title">{t("about.values")}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-4xl mx-auto">
            {[
              {
                icon: Award,
                title: t("about.professionalism"),
                description: t("about.professionalismDesc"),
              },
              {
                icon: Heart,
                title: t("about.honesty"),
                description: t("about.honestyDesc"),
              },
              {
                icon: Users,
                title: t("about.collaboration"),
                description: t("about.collaborationDesc"),
              },
              {
                icon: Target,
                title: t("about.innovation"),
                description: t("about.innovationDesc"),
              },
            ].map((value, idx) => {
              const Icon = value.icon;
              return (
                <div key={idx} className="card-base p-6 text-center">
                  <Icon className="w-10 h-10 text-primary mx-auto mb-4" />
                  <h3 className="font-bold text-lg mb-2">{value.title}</h3>
                  <p className="text-gray-600 dark:text-gray-400 text-sm">
                    {value.description}
                  </p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Founder Section */}
      <section className="section bg-gray-50 dark:bg-gray-900">
        <div className="section-container">
          <h2 className="section-title">{t("about.founder")}</h2>
          <p className="section-subtitle mb-12">
            {t("about.founderSubtitle")}
          </p>

          <TeamMemberCard
            name="لواء دكتور علاء الدين محمد علي عبد المجيد"
            title="مؤسس ورئيس المجموعة"
            image="https://cdn.builder.io/api/v1/image/assets%2F370dc3179dd542e79e831016a3545dec%2F0ca2d21d2fdb48589151cb594efba1ee?format=webp&width=800"
            bio="لواء دكتور متخصص في القانون التجاري والبحري والجوي، بخبرة تزيد عن 40 سنة في مجالات الأمن والقانون والتعليم العالي. حاصل على دكتوراه في القانون من جامعة أسيوط، وقد شغل مناصب قيادية عديدة أهمها نائب رئيس الجامعة العمالية."
            qualifications={[
              "ليسانس حقوق من أكاديمية الشرطة (1985)",
              "دبلوم الدراسات العليا في الشريعة الإسلامية من جامعة القاهرة (2004)",
              "دبلوم الدراسات العليا في القانون الخاص من جامعة القاهرة (2005)",
              "دبلوم العلاقات العامة والإعلام من جامعة سوهاج (2014)",
              "دكتوراه في القانون التجاري والبحري والجوي من جامعة أسيوط (2015)",
            ]}
            experience={[
              "ضابط شرطة بقطاعات وزارة الداخلية المختلفة (1985-2016)",
              "نائب رئيس الجامعة العمالية (2016)",
              "محامي بالنقض والقضاء العسكري (2016-الآن)",
              "مستشار قانوني للعديد من الشركات والمؤسسات (2017-الآن)",
              "محاضر وخبير تدريب في عدة جامعات ومؤسسات (1995-2025)",
            ]}
            contact={{
              location: "الجيزة، مصر / سوهاج",
              phone: "01222717666",
              email: "entelaqa.law@gmail.com",
            }}
          />
        </div>
      </section>

      {/* Team Section */}
      <section className="section">
        <div className="section-container">
          <h2 className="section-title">{t("about.team")}</h2>
          <p className="section-subtitle">
            {t("about.teamSubtitle")}
          </p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {[
              {
                name: "أحمد عبدالجواد",
                title: "المدير المسئول",
              },
              {
                name: "سالي مبروك",
                title: "استشارية قانونية",
              },
              {
                name: "محمد سالم",
                title: "محاسب قانوني معتمد",
              },
            ].map((member, idx) => (
              <div key={idx} className="card-base p-6 text-center hover:shadow-lg transition-all">
                <div className="w-20 h-20 rounded-full bg-primary/20 mx-auto mb-4 flex items-center justify-center">
                  <span className="text-4xl">👤</span>
                </div>
                <h3 className="font-bold text-lg mb-2">{member.name}</h3>
                <p className="text-primary text-sm">{member.title}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="section bg-primary text-primary-foreground">
        <div className="section-container">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
            {[
              { number: "500+", label: t("about.clients") },
              { number: "1000+", label: t("about.cases") },
              { number: "10+", label: t("about.experience") },
              { number: "98%", label: t("about.satisfaction") },
            ].map((stat, idx) => (
              <div key={idx}>
                <div className="text-5xl font-bold mb-2">{stat.number}</div>
                <p className="text-lg opacity-90">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="section">
        <div className="section-container">
          <div className="gradient-hero rounded-2xl p-8 md:p-16 text-center text-white">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">
              {t("about.contactHeading")}
            </h2>
            <p className="text-lg text-gray-100 mb-8 max-w-2xl mx-auto">
              {t("about.contactSubtitle")}
            </p>
            <a href="/contact" className="btn-primary inline-block">
              {t("about.contactButton")}
            </a>
          </div>
        </div>
      </section>
    </Layout>
  );
}
