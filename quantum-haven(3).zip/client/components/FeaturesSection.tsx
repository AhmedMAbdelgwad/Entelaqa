import { useTranslation } from "react-i18next";
import { Award, Zap, DollarSign, Lock, Users, Clock } from "lucide-react";

export const FeaturesSection = () => {
  const { t } = useTranslation();

  const features = [
    {
      icon: Award,
      title: t("features.expertise"),
      description: t("features.expertiseDesc"),
    },
    {
      icon: Zap,
      title: t("features.fastService"),
      description: t("features.fastServiceDesc"),
    },
    {
      icon: DollarSign,
      title: t("features.transparent"),
      description: t("features.transparentDesc"),
    },
    {
      icon: Lock,
      title: t("features.confidential"),
      description: t("features.confidentialDesc"),
    },
    {
      icon: Users,
      title: t("features.dedicated"),
      description: t("features.dedicatedDesc"),
    },
    {
      icon: Clock,
      title: t("features.accessible"),
      description: t("features.accessibleDesc"),
    },
  ];

  return (
    <section className="section bg-gray-50 dark:bg-gray-900">
      <div className="section-container">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="section-title">{t("features.title")}</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, idx) => {
            const Icon = feature.icon;
            return (
              <div key={idx} className="card-base p-8 text-center hover:shadow-lg transition-all">
                <Icon className="w-12 h-12 text-primary mx-auto mb-4" />
                <h3 className="text-xl font-bold mb-3 text-foreground">
                  {feature.title}
                </h3>
                <p className="text-gray-600 dark:text-gray-400">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
