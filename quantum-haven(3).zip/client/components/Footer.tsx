import { Link } from "react-router-dom";
import { Mail, MapPin, Phone } from "lucide-react";
import { useTranslation } from "react-i18next";

export const Footer = () => {
  const { t, i18n } = useTranslation();
  const isArabic = i18n.language === "ar";

  return (
    <footer className="bg-primary text-primary-foreground mt-20">
      <div className="section-container py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div>
            <h3 className="text-xl font-bold mb-4">مجموعة انطلاقة للمحاماة والاستشارات</h3>
            <p className="text-sm opacity-90 leading-relaxed">
              نقدم خدمات استشارات قانونية متخصصة وشاملة لتلبية احتياجات الأفراد والشركات.
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t("footer.followUs")}</h4>
            <ul className="space-y-2 text-sm">
              <li>
                <Link to="/" className="hover:opacity-75 transition-opacity">
                  {t("nav.home")}
                </Link>
              </li>
              <li>
                <Link to="/services" className="hover:opacity-75 transition-opacity">
                  {t("nav.services")}
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:opacity-75 transition-opacity">
                  {t("nav.about")}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:opacity-75 transition-opacity">
                  {t("nav.contact")}
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">{t("nav.contact")}</h4>
            <ul className="space-y-3 text-sm">
              <li className="flex items-center gap-2">
                <Phone className="w-4 h-4" />
                <a href="tel:+201061963341" className="hover:opacity-75 transition-opacity">
                  +201061963341
                </a>
              </li>
              <li className="flex items-center gap-2">
                <Mail className="w-4 h-4" />
                <a
                  href="mailto:entelaqa.law@gmail.com"
                  className="hover:opacity-75 transition-opacity break-all"
                >
                  entelaqa.law@gmail.com
                </a>
              </li>
              <li className="flex gap-2">
                <MapPin className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <span className="leading-relaxed">37 شارع ربيع الجيزي - الجيزة - مصر</span>
              </li>
            </ul>
          </div>

          {/* Branches Info */}
          <div>
            <h4 className="text-lg font-semibold mb-4">
              {isArabic ? "فروعنا" : "Our Branches"}
            </h4>
            <ul className="space-y-3 text-sm">
              <li className="leading-relaxed">
                <p className="font-semibold mb-1">{isArabic ? "سوهاج" : "Sohag"}</p>
                <p className="opacity-90 text-xs">
                  عمارة النقل - شارع بورسعيد من ميدان الثقافة
                </p>
              </li>
              <li className="leading-relaxed border-t border-primary-foreground/20 pt-3">
                <p className="font-semibold mb-1">{isArabic ? "الغردقة" : "Hurghada"}</p>
                <p className="opacity-90 text-xs">
                  عمارة بيت الضرائب - شارع الضهار أمام المحكمة
                </p>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-primary-foreground/20 pt-8 text-center text-sm opacity-90">
          <p>© 2025 انطلاقة للمحاماة والاستشارات القانونية. {t("footer.rights")}</p>
        </div>
      </div>
    </footer>
  );
};
