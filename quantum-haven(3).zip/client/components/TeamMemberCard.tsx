interface TeamMemberCardProps {
  name: string;
  title: string;
  image?: string;
  bio?: string;
  qualifications?: string[];
  experience?: string[];
  contact?: {
    phone?: string;
    email?: string;
    location?: string;
  };
}

export const TeamMemberCard = ({
  name,
  title,
  image,
  bio,
  qualifications,
  experience,
  contact,
}: TeamMemberCardProps) => {
  return (
    <div className="card-base p-8 md:p-12 overflow-hidden">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {/* Image Column */}
        {image && (
          <div className="md:col-span-1 flex items-start justify-center">
            <div className="w-full aspect-square rounded-lg overflow-hidden shadow-lg border-4 border-primary/20">
              <img
                src={image}
                alt={name}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        )}

        {/* Content Column */}
        <div className={image ? "md:col-span-2" : "md:col-span-3"}>
          {/* Header */}
          <div className="mb-8 border-b-2 border-primary/30 pb-6">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-2">
              {name}
            </h2>
            <p className="text-xl text-primary font-semibold">{title}</p>
          </div>

          {/* Bio */}
          {bio && (
            <div className="mb-8">
              <p className="text-gray-700 dark:text-gray-300 leading-relaxed text-lg">
                {bio}
              </p>
            </div>
          )}

          {/* Qualifications */}
          {qualifications && qualifications.length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">
                المؤهلات العلمية
              </h3>
              <div className="space-y-3">
                {qualifications.map((qual, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <span className="text-primary font-bold text-lg flex-shrink-0">
                      ✓
                    </span>
                    <p className="text-gray-700 dark:text-gray-300">{qual}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Experience */}
          {experience && experience.length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-bold text-primary mb-4">
                الخبرات الرئيسية
              </h3>
              <div className="space-y-3">
                {experience.map((exp, idx) => (
                  <div key={idx} className="flex items-start gap-3">
                    <span className="text-primary font-bold text-lg flex-shrink-0">
                      •
                    </span>
                    <p className="text-gray-700 dark:text-gray-300">{exp}</p>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Contact Information */}
          {contact && (
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-6 border-t border-primary/30">
              {contact.location && (
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 font-semibold mb-1">
                    37 شارع ربيع الجيزي - الجيزة - مصر
                  </p>
                  <p className="text-foreground">{contact.location}</p>
                </div>
              )}
              {contact.phone && (
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 font-semibold mb-1">
                    الهاتف
                  </p>
                  <a
                    href={`tel:${contact.phone}`}
                    className="text-primary hover:underline"
                  >
                    {contact.phone}
                  </a>
                </div>
              )}
              {contact.email && (
                <div>
                  <p className="text-sm text-gray-600 dark:text-gray-400 font-semibold mb-1">
                    البريد
                  </p>
                  <a
                    href={`mailto:${contact.email}`}
                    className="text-primary hover:underline break-all"
                  >
                    {contact.email}
                  </a>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
