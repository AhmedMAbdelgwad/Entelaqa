import { ChevronDown } from "lucide-react";
import { useState } from "react";
import { useTranslation } from "react-i18next";

export const FAQSection = () => {
  const { t } = useTranslation();
  const [openId, setOpenId] = useState<number | null>(null);

  const faqs = [
    {
      id: 1,
      question: "كيف يمكن حجز استشارة؟",
      answer:
        "يمكنك حجز استشارة من خلال الاتصال بنا مباشرة عبر الهاتف أو البريد الإلكتروني، أو ملء نموذج الحجز على موقعنا. سيتواصل معك فريقنا في أسرع وقت.",
    },
    {
      id: 2,
      question: "ما هي تكلفة الاستشارة؟",
      answer:
        "تختلف تكلفة الاستشارة حسب نوع الخدمة والحالة. نقدم استشارة أولية مجانية لتقييم احتياجاتك ثم نقدم الأسعار المناسبة.",
    },
    {
      id: 3,
      question: "ما هي طرق الدفع؟",
      answer:
        "نقبل جميع طرق الدفع الشهيرة منها التحويل البنكي، الدفع النقدي، والمحافظ الرقمية. لمزيد من التفاصيل، تواصل معنا مباشرة.",
    },
    {
      id: 4,
      question: "ما هي مواعيد العمل؟",
      answer:
        "نعمل من الأحد إلى الخميس من الساعة 9 صباحاً إلى 5 مساءً. للحالات الطارئة، يمكنك التواصل معنا في أي وقت.",
    },
    {
      id: 5,
      question: "كيف تتم الاستشارة؟",
      answer:
        "تتم الاستشارة عن طريق الاجتماع المباشر في مكتبنا أو عبر مكالمة فيديو حسب رغبتك وملاءمة وقتك. كل ذلك حسب احتياجاتك.",
    },
    {
      id: 6,
      question: "ما هي مدة الانتظار لتلقي الاتصال؟",
      answer:
        "نحاول التواصل معك في غضون 24 ساعة من استقبال طلبك. في حالات الطلبات المستعجلة، قد نتواصل معك في نفس اليوم.",
    },
  ];

  return (
    <section className="section bg-gray-50 dark:bg-gray-900">
      <div className="section-container">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="section-title">{t("faq.title")}</h2>
          <p className="section-subtitle">{t("faq.subtitle")}</p>
        </div>

        {/* FAQ Items */}
        <div className="max-w-3xl mx-auto space-y-4">
          {faqs.map((faq) => (
            <button
              key={faq.id}
              onClick={() => setOpenId(openId === faq.id ? null : faq.id)}
              className="w-full"
            >
              <div className="card-base p-6 text-right hover:shadow-lg transition-all duration-300">
                <div className="flex items-center justify-between gap-4">
                  <ChevronDown
                    className={`w-5 h-5 text-primary flex-shrink-0 transition-transform duration-300 ${
                      openId === faq.id ? "rotate-180" : ""
                    }`}
                  />
                  <h3 className="text-lg font-semibold text-foreground flex-1">
                    {faq.question}
                  </h3>
                </div>

                {/* Answer */}
                {openId === faq.id && (
                  <div className="mt-4 pt-4 border-t border-border">
                    <p className="text-gray-600 dark:text-gray-400 leading-relaxed text-right">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </div>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
