import { Star } from "lucide-react";
import { useState } from "react";
import { useTranslation } from "react-i18next";

export const TestimonialsSection = () => {
  const { t } = useTranslation();
  const [formData, setFormData] = useState({ name: "", review: "" });

  const testimonials = [
    {
      id: 1,
      name: "أسامة السيد",
      rating: 4.5,
      text: "خدمة ممتازة وسرعة في إنجاز الإجراءات، أنصح بالتعامل معهم بشدة. فريق محترف جداً.",
    },
    {
      id: 2,
      name: "نهلة علي",
      rating: 5,
      text: "الاستشارة كانت مفيدة جداً وساعدتني في اتخاذ قرارات مهمة. شكراً على الاحترافية.",
    },
  ];

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission
    console.log("Form submitted:", formData);
    setFormData({ name: "", review: "" });
  };

  return (
    <section className="section">
      <div className="section-container">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="section-title">{t("testimonials.title")}</h2>
          <p className="section-subtitle">{t("testimonials.subtitle")}</p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {testimonials.map((testimonial) => (
            <div key={testimonial.id} className="card-base p-8">
              <div className="mb-4 flex gap-1">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-5 h-5 ${
                      i < Math.floor(testimonial.rating)
                        ? "fill-accent text-accent"
                        : i < testimonial.rating
                          ? "fill-accent text-accent"
                          : "text-gray-300"
                    }`}
                  />
                ))}
              </div>
              <p className="text-foreground mb-6 leading-relaxed">{testimonial.text}</p>
              <p className="font-semibold text-primary">{testimonial.name}</p>
            </div>
          ))}
        </div>

        {/* Review Submission */}
        <div className="card-base p-8 max-w-2xl mx-auto">
          <h3 className="text-2xl font-bold mb-6 text-center">شاركنا آراءك</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <input
                type="text"
                name="name"
                placeholder="اسمك الكامل"
                value={formData.name}
                onChange={handleChange}
                className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-900"
                required
              />
            </div>
            <div>
              <textarea
                name="review"
                placeholder="شاركنا رأيك..."
                value={formData.review}
                onChange={handleChange}
                rows={4}
                className="w-full px-4 py-3 rounded-lg border border-border focus:outline-none focus:ring-2 focus:ring-primary bg-white dark:bg-gray-900"
                required
              />
            </div>
            <button type="submit" className="btn-primary w-full">
              {t("contact.sendButton")}
            </button>
          </form>
        </div>
      </div>
    </section>
  );
};
