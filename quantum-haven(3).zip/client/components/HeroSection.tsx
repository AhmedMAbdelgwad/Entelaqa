import { Link } from "react-router-dom";
import { ArrowLeft, HelpCircle } from "lucide-react";
import { useTranslation } from "react-i18next";

export const HeroSection = () => {
  const { t } = useTranslation();
  return (
    <section className="gradient-hero text-white py-16 md:py-24">
      <div className="section-container">
        {/* Logo */}
        <div className="flex justify-center mb-8">
          <img
            src="https://cdn.builder.io/api/v1/image/assets%2F370dc3179dd542e79e831016a3545dec%2F0eb4b0d316cc47e7a7ced262f42bd8c3?format=webp&width=800"
            alt="محمّوعة النقّاق"
            className="h-20 md:h-28 w-auto"
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            <div className="space-y-4">
              <h1 className="text-white leading-tight">
                {t("hero.title")}
              </h1>
              <p className="text-lg md:text-xl text-gray-100 leading-relaxed">
                {t("hero.subtitle")}
              </p>
            </div>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Link
                to="/contact"
                className="btn-primary inline-flex items-center justify-center gap-2 hover:scale-105 transition-transform"
              >
                {t("hero.bookButton")}
                <ArrowLeft className="w-5 h-5" />
              </Link>
              <Link
                to="/services"
                className="px-6 py-3 rounded-lg border-2 border-white text-white font-semibold hover:bg-white hover:text-primary transition-all duration-200 inline-flex items-center justify-center gap-2"
              >
                {t("hero.servicesButton")}
                <ArrowLeft className="w-5 h-5" />
              </Link>
            </div>

            {/* Secondary CTA */}
            <div className="pt-4">
              <button className="flex items-center gap-3 text-white hover:opacity-80 transition-opacity group">
                <div className="w-12 h-12 rounded-full bg-yellow-400 flex items-center justify-center group-hover:scale-110 transition-transform">
                  <HelpCircle className="w-6 h-6 text-primary" />
                </div>
                <span className="font-semibold text-lg">{t("hero.aboutButton")}</span>
              </button>
            </div>
          </div>

          {/* Right Image Placeholder */}
          <div className="hidden md:block">
            <div className="relative">
              <div className="absolute inset-0 bg-gradient-to-b from-blue-400 to-blue-600 rounded-2xl opacity-20 blur-xl" />
              <div className="relative bg-white/10 backdrop-blur-sm rounded-2xl p-12 border border-white/20 aspect-square flex items-center justify-center">
                <div className="text-center">
                  <div className="text-6xl mb-4">⚖️</div>
                  <p className="text-white/80 text-lg">{t("services.legalConsultations")}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
