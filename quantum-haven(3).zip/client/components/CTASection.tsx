import { Link } from "react-router-dom";
import { ArrowLeft } from "lucide-react";
import { useTranslation } from "react-i18next";

export const CTASection = () => {
  const { t } = useTranslation();

  return (
    <section className="section">
      <div className="section-container">
        <div className="gradient-hero rounded-2xl p-8 md:p-16 text-center text-white">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">{t("cta.heading")}</h2>
          <p className="text-lg text-gray-100 mb-8 max-w-2xl mx-auto">
            {t("cta.subheading")}
          </p>
          <Link
            to="/contact"
            className="btn-primary inline-flex items-center justify-center gap-2 hover:scale-105 transition-transform"
          >
            {t("cta.button")}
            <ArrowLeft className="w-5 h-5" />
          </Link>
        </div>
      </div>
    </section>
  );
};
