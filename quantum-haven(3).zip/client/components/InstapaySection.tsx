import { useTranslation } from "react-i18next";
import { QrCode, CheckCircle } from "lucide-react";

export const InstapaySection = () => {
  const { t, i18n } = useTranslation();

  const qrCodeValue = "https://www.instapay.eg";
  const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${encodeURIComponent(
    qrCodeValue
  )}`;

  const isArabic = i18n.language === "ar";

  return (
    <section className="section bg-gradient-to-br from-primary/5 to-accent/5">
      <div className="section-container">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="section-title">{t("payment.title")}</h2>
          <p className="section-subtitle">{t("payment.subtitle")}</p>
        </div>

        <div className="max-w-4xl mx-auto">
          <div className="bg-white dark:bg-gray-800 rounded-2xl shadow-xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 p-8 md:p-12">
              {/* QR Code Section */}
              <div className="flex flex-col items-center justify-center">
                <div className="mb-6">
                  <QrCode className="w-12 h-12 text-primary mx-auto mb-4" />
                  <h3 className="text-2xl font-bold text-center text-foreground mb-2">
                    InstaPay
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 text-center">
                    {isArabic
                      ? "امسح رمز QR للدفع"
                      : "Scan QR Code to Pay"}
                  </p>
                </div>

                <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg">
                  <img
                    src={qrCodeUrl}
                    alt="InstaPay QR Code"
                    className="w-80 h-80 rounded"
                  />
                </div>

                <p className="text-center text-sm text-gray-600 dark:text-gray-400 mt-4">
                  {isArabic
                    ? "امسح هذا الرمز باستخدام تطبيق InstaPay"
                    : "Scan this code using InstaPay app"}
                </p>
              </div>

              {/* Payment Info Section */}
              <div className="flex flex-col justify-center">
                <h3 className="text-2xl font-bold text-foreground mb-6">
                  {isArabic ? "طرق الدفع" : "Payment Methods"}
                </h3>

                <div className="space-y-4">
                  <div className="flex items-start gap-3">
                    <CheckCircle className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                    <div>
                      <h4 className="font-semibold text-foreground mb-1">
                        InstaPay
                      </h4>
                      <p className="text-sm text-gray-600 dark:text-gray-400">
                        {isArabic
                          ? "الدفع الفوري والآمن عبر تطبيق InstaPay"
                          : "Instant and secure payment via InstaPay app"}
                      </p>
                    </div>
                  </div>

                  <div className="border-t border-gray-200 dark:border-gray-700 pt-4 mt-4">
                    <h4 className="font-semibold text-foreground mb-3">
                      {isArabic ? "خطوات الدفع:" : "Payment Steps:"}
                    </h4>
                    <ol className="space-y-2 text-sm text-gray-600 dark:text-gray-400">
                      <li className="flex items-start gap-2">
                        <span className="font-bold text-primary flex-shrink-0">
                          1
                        </span>
                        <span>
                          {isArabic
                            ? "قم بتحميل تطبيق InstaPay"
                            : "Download InstaPay app"}
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="font-bold text-primary flex-shrink-0">
                          2
                        </span>
                        <span>
                          {isArabic
                            ? "امسح رمز QR أعلاه"
                            : "Scan the QR code above"}
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="font-bold text-primary flex-shrink-0">
                          3
                        </span>
                        <span>
                          {isArabic
                            ? "أدخل المبلغ المطلوب"
                            : "Enter the amount"}
                        </span>
                      </li>
                      <li className="flex items-start gap-2">
                        <span className="font-bold text-primary flex-shrink-0">
                          4
                        </span>
                        <span>
                          {isArabic
                            ? "أكمل عملية الدفع"
                            : "Complete the payment"}
                        </span>
                      </li>
                    </ol>
                  </div>
                </div>

                <div className="mt-8 p-4 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <p className="text-sm text-blue-900 dark:text-blue-300">
                    {isArabic
                      ? "يمكنك الاتصال بنا لأي استفسارات حول طرق الدفع"
                      : "Contact us for any inquiries about payment methods"}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Info */}
        <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h4 className="font-semibold text-foreground mb-2">
              {isArabic ? "آمن وموثوق" : "Safe & Secure"}
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {isArabic
                ? "معاملات آمنة وموثوقة"
                : "Secure transactions"}
            </p>
          </div>

          <div className="text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h4 className="font-semibold text-foreground mb-2">
              {isArabic ? "فوري" : "Instant"}
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {isArabic
                ? "دفع فوري بدون تأخير"
                : "Instant payment processing"}
            </p>
          </div>

          <div className="text-center p-6 bg-white dark:bg-gray-800 rounded-lg shadow">
            <h4 className="font-semibold text-foreground mb-2">
              {isArabic ? "سهل الاستخدام" : "Easy to Use"}
            </h4>
            <p className="text-sm text-gray-600 dark:text-gray-400">
              {isArabic
                ? "واجهة سهلة وبسيطة"
                : "Simple and straightforward"}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
