import { Link } from "react-router-dom";
import { useTranslation } from "react-i18next";
import {
  MessageSquare,
  Building2,
  Calculator,
  Plane,
  CheckCircle,
  Scale,
  FileText,
  Home,
  Package,
  Lightbulb,
  Car,
  ArrowLeft,
} from "lucide-react";

export const ServicesSection = () => {
  const { t } = useTranslation();

  const services = [
    {
      id: 1,
      title: t("services.legalConsultations"),
      description: t("services.legalConsultationsDesc"),
      icon: MessageSquare,
    },
    {
      id: 2,
      title: t("services.companyFormation"),
      description: t("services.companyFormationDesc"),
      icon: Building2,
    },
    {
      id: 3,
      title: t("services.accounting"),
      description: t("services.accountingDesc"),
      icon: Calculator,
    },
    {
      id: 4,
      title: t("services.procedural"),
      description: t("services.proceduralDesc"),
      icon: CheckCircle,
    },
    {
      id: 5,
      title: t("services.realEstate"),
      description: t("services.realEstateDesc"),
      icon: Building2,
    },
    {
      id: 6,
      title: t("services.customs"),
      description: t("services.customsDesc"),
      icon: Plane,
    },
    {
      id: 7,
      title: t("services.intellectualProperty"),
      description: t("services.intellectualPropertyDesc"),
      icon: MessageSquare,
    },
    {
      id: 8,
      title: t("services.abroadServices"),
      description: t("services.abroadServicesDesc"),
      icon: Plane,
    },
    {
      id: 9,
      title: t("services.disputes"),
      description: t("services.disputesDesc"),
      icon: Scale,
    },
    {
      id: 10,
      title: t("services.vehicleLicenses"),
      description: t("services.vehicleLicensesDesc"),
      icon: Car,
    },
  ];
  return (
    <section className="section bg-gray-50 dark:bg-gray-900">
      <div className="section-container">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="section-title">{t("services.title")}</h2>
          <p className="section-subtitle">
            {t("services.subtitle")}
          </p>
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12">
          {services.map((service) => {
            const Icon = service.icon;
            return (
              <div
                key={service.id}
                className="card-base p-8 flex flex-col hover:translate-y-[-4px] transition-all duration-300"
              >
                <div className="mb-4">
                  <Icon className="w-10 h-10 text-primary" />
                </div>
                <h3 className="text-xl font-bold mb-3 text-foreground">{service.title}</h3>
                <p className="text-gray-600 dark:text-gray-400 flex-1 mb-4">
                  {service.description}
                </p>
                <Link
                  to="/services"
                  className="text-primary font-semibold hover:opacity-75 transition-opacity inline-flex items-center gap-2"
                >
                  {t("services.viewMore")}
                  <ArrowLeft className="w-4 h-4" />
                </Link>
              </div>
            );
          })}
        </div>

        {/* CTA Button */}
        <div className="text-center">
          <Link to="/services" className="btn-primary inline-block">
            {t("services.viewAll")}
          </Link>
        </div>
      </div>
    </section>
  );
};
