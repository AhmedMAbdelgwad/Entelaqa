import { useTranslation } from "react-i18next";
import { MapPin, Phone, Mail, Clock } from "lucide-react";

export const BranchesSection = () => {
  const { t, i18n } = useTranslation();

  const branches = [
    {
      name: "الفرع الرئيسي - الجيزة",
      address: "37 شارع ربيع الجيزي - الجيزة - مصر",
      phone: "+20 1061963341",
      email: "entelaqa.law@gmail.com",
      hours: "الأحد - الخميس: 9:00 - 17:00",
      isMain: true,
    },
    {
      name: "فرع سوهاج",
      address: "عمارة النقل - شارع بورسعيد من ميدان الثقافة - سوهاج - مصر",
      phone: "+20 1222717666",
      email: "entelaqa.law@gmail.com",
      hours: "الأحد - الخميس: 9:00 - 17:00",
      isMain: false,
    },
    {
      name: "فرع الغردقة",
      address: "عمارة بيت الضرائب - شارع الضهار أمام المحكمة - الغردقة - مصر",
      phone: "+20 1061963341",
      email: "entelaqa.law@gmail.com",
      hours: "الأحد - الخميس: 9:00 - 17:00",
      isMain: false,
    },
  ];

  const isArabic = i18n.language === "ar";

  return (
    <section className="section bg-gray-50 dark:bg-gray-900">
      <div className="section-container">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="section-title">
            {isArabic ? "فروعنا" : "Our Branches"}
          </h2>
          <p className="section-subtitle">
            {isArabic
              ? "تواصل معنا في أقرب فرع إليك"
              : "Contact us at the nearest branch to you"}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto">
          {branches.map((branch, idx) => (
            <div
              key={idx}
              className={`card-base p-6 md:p-8 ${
                branch.isMain ? "md:col-span-3 lg:col-span-1 border-2 border-primary" : ""
              }`}
            >
              <div className="flex items-start gap-3 mb-4">
                <MapPin className="w-6 h-6 text-primary flex-shrink-0 mt-1" />
                <h3 className="text-xl font-bold text-foreground">
                  {branch.name}
                </h3>
              </div>

              <div className="space-y-4 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex gap-3">
                  <MapPin className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <p className="leading-relaxed">{branch.address}</p>
                </div>

                <div className="flex gap-3">
                  <Phone className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <a
                    href={`tel:${branch.phone}`}
                    className="text-primary hover:underline"
                  >
                    {branch.phone}
                  </a>
                </div>

                <div className="flex gap-3">
                  <Mail className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <a
                    href={`mailto:${branch.email}`}
                    className="text-primary hover:underline break-all"
                  >
                    {branch.email}
                  </a>
                </div>

                <div className="flex gap-3">
                  <Clock className="w-5 h-5 text-primary flex-shrink-0 mt-0.5" />
                  <p>{branch.hours}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
