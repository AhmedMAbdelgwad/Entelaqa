import { useTranslation } from "react-i18next";
import { CreditCard, Banknote, Smartphone, Heart, Clock } from "lucide-react";

export const PaymentMethodsSection = () => {
  const { t } = useTranslation();

  const methods = [
    {
      icon: Banknote,
      title: t("payment.bankTransfer"),
      description: t("payment.bankTransferDesc"),
    },
    {
      icon: Heart,
      title: t("payment.cash"),
      description: t("payment.cashDesc"),
    },
    {
      icon: CreditCard,
      title: t("payment.cards"),
      description: t("payment.cardsDesc"),
    },
    {
      icon: Smartphone,
      title: t("payment.digital"),
      description: t("payment.digitalDesc"),
    },
    {
      icon: Clock,
      title: t("payment.installment"),
      description: t("payment.installmentDesc"),
    },
  ];

  return (
    <section className="section">
      <div className="section-container">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="section-title">{t("payment.title")}</h2>
          <p className="section-subtitle">{t("payment.subtitle")}</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6 max-w-5xl mx-auto">
          {methods.map((method, idx) => {
            const Icon = method.icon;
            return (
              <div
                key={idx}
                className="card-base p-6 text-center hover:shadow-lg transition-all"
              >
                <Icon className="w-10 h-10 text-primary mx-auto mb-4" />
                <h3 className="font-bold text-lg mb-2 text-foreground">
                  {method.title}
                </h3>
                <p className="text-sm text-gray-600 dark:text-gray-400">
                  {method.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Additional Info */}
        <div className="mt-12 p-8 bg-primary text-primary-foreground rounded-lg">
          <div className="text-center">
            <h3 className="text-2xl font-bold mb-4">مرونة في الدفع</h3>
            <p className="max-w-2xl mx-auto">
              نفهم أن كل عميل له احتياجات مختلفة. لذا نقدم خطط دفع مرنة وخيارات متعددة لتسهيل التعامل معنا
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
